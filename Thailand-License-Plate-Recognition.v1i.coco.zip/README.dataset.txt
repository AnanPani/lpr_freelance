# Thailand-License-Plate-Recognition > 2022-03-27 12:24am
https://universe.roboflow.com/dataset-format-conversion-iidaz/thailand-license-plate-recognition

Provided by a Roboflow user
License: CC BY 4.0

